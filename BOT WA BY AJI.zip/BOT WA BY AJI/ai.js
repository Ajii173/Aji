const axios = require('axios')

exports.command = "ai"

exports.run = async (sock, msg, text) => {
    const from = msg.key.remoteJid
    const q = text.replace("!ai ", "")

    let res = await axios.get(`https://api.affiliateplus.xyz/api/chatbot?message=${q}`)
    await sock.sendMessage(from, { text: res.data.message })
}