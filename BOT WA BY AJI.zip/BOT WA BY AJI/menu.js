await sock.sendMessage(from, {
    text: "🔥 BOT DEWA MENU",
    footer: "Pilih menu di bawah",
    buttons: [
        { buttonId: "!menu", buttonText: { displayText: "📜 Menu" }, type: 1 },
        { buttonId: "!ping", buttonText: { displayText: "⚡ Ping" }, type: 1 },
        { buttonId: "!ai halo", buttonText: { displayText: "🤖 AI" }, type: 1 }
    ],
    headerType: 1
})