exports.command = "sticker"

exports.run = async (sock, msg) => {
    await sock.sendMessage(msg.key.remoteJid, {
        sticker: { url: "https://i.ibb.co/6bQ6Z9p/cat.png" }
    })
}