exports.command = "tebak"

let angka = Math.floor(Math.random() * 10)

exports.run = async (sock, msg) => {
    await sock.sendMessage(msg.key.remoteJid, {
        text: `Tebak angka 0-9 (jawaban: ${angka})`
    })
}