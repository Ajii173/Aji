exports.command = "tiktok"

exports.run = async (sock, msg, { text }) => {
    const from = msg.key.remoteJid

    await sock.sendMessage(from, {
        text: "Downloader aktif (tinggal sambung API 🔥)"
    })
}