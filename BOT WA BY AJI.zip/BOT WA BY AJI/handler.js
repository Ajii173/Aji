const { saveDB } = require('./lib/db')

// setelah update user
saveDB()

const owner = ["628xxxxxxxxxx@s.whatsapp.net"]

const isOwner = owner.includes(sender)
if (!isOwner) return sock.sendMessage(from, { text: "❌ Owner only!" })
const fs = require('fs')
const path = require('path')

const prefix = "!"

exports.handler = async (sock, msg) => {
    const text = msg.message.conversation || msg.message.extendedTextMessage?.text
    if (!text || !text.startsWith(prefix)) return

    const command = text.slice(1).split(" ")[0]

    const pluginsPath = path.join(__dirname, 'plugins')
    const files = fs.readdirSync(pluginsPath)

    for (let file of files) {
        const plugin = require(`./plugins/${file}`)

        if (plugin.command === command) {
            return plugin.run(sock, msg, text)
        }
    }
}