exports.command = "antilink"

let aktif = false

exports.run = async (sock, msg, { text }) => {
    const from = msg.key.remoteJid

    if (text.includes("on")) aktif = true
    if (text.includes("off")) aktif = false

    await sock.sendMessage(from, {
        text: aktif ? "Anti-link ON 🚫" : "Anti-link OFF ✅"
    })
}