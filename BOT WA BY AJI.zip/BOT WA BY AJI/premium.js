if (!db.premium.includes(sender)) {
   return sock.sendMessage(from, { text: "❌ Khusus premium!" })
}

exports.command = "premium"

exports.run = async (sock, msg, { db }) => {
    const from = msg.key.remoteJid
    const sender = msg.key.participant || from

    if (!db.premium) db.premium = []

    if (db.premium.includes(sender)) {
        return sock.sendMessage(from, { text: "💎 Kamu sudah premium!" })
    }

    db.premium.push(sender)

    await sock.sendMessage(from, {
        text: "🎉 Kamu sekarang user PREMIUM!"
    })
}