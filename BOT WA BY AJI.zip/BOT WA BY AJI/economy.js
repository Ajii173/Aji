const { saveDB } = require('../lib/db')

exports.command = "work"

exports.run = async (sock, msg, { db }) => {
    const from = msg.key.remoteJid
    const sender = msg.key.participant || from

    let uang = Math.floor(Math.random() * 1000)
    db.users[sender].money += uang

    saveDB()

    await sock.sendMessage(from, {
        text: `💰 Kamu kerja dan dapat ${uang} koin!`
    })
}