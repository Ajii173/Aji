const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys')
const axios = require('axios')
const fs = require('fs')

const prefix = "!"

// database sederhana
let db = JSON.parse(fs.readFileSync('./db.json', 'utf-8') || '{}')

function saveDB() {
    fs.writeFileSync('./db.json', JSON.stringify(db, null, 2))
}

function addUser(id) {
    if (!db[id]) {
        db[id] = { xp: 0, level: 1 }
    }
}

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth')

    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    })

    sock.ev.on('creds.update', saveCreds)

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message) return

        const from = msg.key.remoteJid
        const sender = msg.key.participant || from
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text

        if (!text) return

        addUser(sender)
        db[sender].xp += 5

        if (db[sender].xp >= 100) {
            db[sender].level += 1
            db[sender].xp = 0
        }

        saveDB()

        // ===== MENU =====
        if (text === "!menu") {
            return sock.sendMessage(from, {
                text: `🔥 *BOT PRO MENU*

👤 User:
Level: ${db[sender].level}
XP: ${db[sender].xp}

📌 COMMAND:
!menu
!ping
!ai teks
!sticker
!tebak
!jawab
!yt judul
!tiktok link
!level
!antilink on/off
`
            })
        }

        // ===== LEVEL =====
        if (text === "!level") {
            return sock.sendMessage(from, {
                text: `Level kamu: ${db[sender].level}\nXP: ${db[sender].xp}`
            })
        }

        // ===== PING =====
        if (text === "!ping") {
            return sock.sendMessage(from, { text: "Pong! 🏓" })
        }

        // ===== AI =====
        if (text.startsWith("!ai ")) {
            let tanya = text.replace("!ai ", "")
            let res = await axios.get(`https://api.affiliateplus.xyz/api/chatbot?message=${tanya}`)
            return sock.sendMessage(from, { text: res.data.message })
        }

        // ===== GAME =====
        if (text === "!tebak") {
            let angka = Math.floor(Math.random() * 10)
            db[from] = angka
            return sock.sendMessage(from, { text: "🎯 Tebak angka 0-9" })
        }

        if (text.startsWith("!jawab ")) {
            let jawab = parseInt(text.split(" ")[1])
            if (db[from] == jawab) {
                return sock.sendMessage(from, { text: "🎉 Benar!" })
            } else {
                return sock.sendMessage(from, { text: "❌ Salah!" })
            }
        }

        // ===== YOUTUBE =====
        if (text.startsWith("!yt ")) {
            let q = text.replace("!yt ", "")
            return sock.sendMessage(from, { text: `Cari: ${q}` })
        }

        // ===== TIKTOK =====
        if (text.startsWith("!tiktok ")) {
            return sock.sendMessage(from, { text: "Downloader belum dihubungkan API 😅" })
        }

        // ===== STICKER =====
        if (msg.message.imageMessage && text === "!sticker") {
            return sock.sendMessage(from, {
                sticker: { url: "https://i.ibb.co/6bQ6Z9p/cat.png" }
            })
        }

        // ===== ANTILINK =====
        if (text === "!antilink on") {
            db.antilink = true
            return sock.sendMessage(from, { text: "Anti-link aktif 🚫" })
        }

        if (text === "!antilink off") {
            db.antilink = false
            return sock.sendMessage(from, { text: "Anti-link mati ✅" })
        }

        if (db.antilink && text.includes("https://chat.whatsapp.com")) {
            return sock.sendMessage(from, { text: "🚫 Link grup dilarang!" })
        }

    })
}

startBot()